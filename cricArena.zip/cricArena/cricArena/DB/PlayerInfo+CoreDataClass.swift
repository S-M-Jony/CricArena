//
//  PlayerInfo+CoreDataClass.swift
//  cricArena
//
//  Created by Shahnewaz on 21/2/23.
//
//

import Foundation
import CoreData

@objc(PlayerInfo)
public class PlayerInfo: NSManagedObject {

}
