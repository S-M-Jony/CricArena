//
//  SearchPlayerTableViewCell.swift
//  cricArena
//
//  Created by bjit on 20/2/23.
//

import UIKit
class SearchPlayerTableViewCell: UITableViewCell {
    @IBOutlet weak var playerImage: UIImageView!
    @IBOutlet weak var playerName: UILabel!
    @IBOutlet weak var allPlayerView: UIView!
    var trappedPlayerId: Int?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        allPlayerView.cornerRadius()
        allPlayerView.shadow()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    func setPlayer(playerInfo: PlayerInfo) {
        playerName.text = playerInfo.playerName
        playerImage.sd_setImage(
            with: URL(string: playerInfo.playerImage ?? ""),
            placeholderImage: UIImage(named:"person2")
        )
    }
}
