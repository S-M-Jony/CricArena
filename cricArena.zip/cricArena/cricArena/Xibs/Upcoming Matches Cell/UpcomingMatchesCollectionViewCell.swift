//
//  UpcomingMatchesCollectionViewCell.swift
//  cricArena
//
//  Created by bjit on 14/2/23.
//

import UIKit
class UpcomingMatchesCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var upcomingMatchView: UIView!
    @IBOutlet weak var upcomingTournament: UILabel!
    @IBOutlet weak var homeTeamFlag: UIImageView!
    @IBOutlet weak var homeTeamName: UILabel!
    @IBOutlet weak var awayTeamFlag: UIImageView!
    @IBOutlet weak var awayTeamName: UILabel!
    @IBOutlet weak var vsLayout: UILabel!
    @IBOutlet weak var upcomingMatchDate: UILabel!
    @IBOutlet weak var countDown: UILabel!
    @IBOutlet weak var upcomingLayout: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        upcomingMatchView.layer.cornerRadius = 10
        upcomingMatchView.layer.shadowColor = UIColor.black.cgColor
        upcomingMatchView.layer.shadowOpacity = 0.5
        upcomingMatchView.layer.shadowOffset = CGSize(width: 0, height: 2)
        upcomingMatchView.layer.shadowRadius = 2
        upcomingMatchView.layer.masksToBounds = false
        vsLayout.layer.cornerRadius = 0.5 * vsLayout.bounds.size.width
        vsLayout.clipsToBounds = true
        upcomingLayout.layer.cornerRadius = 10
        upcomingLayout.layer.masksToBounds = true
    }
    func setMatch(matchInfo: Match) {
        upcomingTournament.text = matchInfo.round
        homeTeamName.text = matchInfo.localteam?.code
        awayTeamName.text = matchInfo.visitorteam?.code
        
        homeTeamFlag.sd_setImage(
            with: URL(string: matchInfo.localteam?.image_path ?? ""),
            placeholderImage: UIImage(named: "ban")
        )
        
        awayTeamFlag.sd_setImage(
            with: URL(string: matchInfo.visitorteam?.image_path ?? ""),
            placeholderImage: UIImage(named: "ind")
        )
        upcomingLayout.layer.cornerRadius = 10
        let upcomingMatchdateTime = sharedData().covertingDateTime(data: matchInfo.starting_at ?? "")
        upcomingMatchDate.text = upcomingMatchdateTime.1+", " + upcomingMatchdateTime.0
        let dateString = matchInfo.starting_at
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSSSSZ"
        guard let date = dateFormatter.date(from: dateString) else {
            fatalError("Invalid date string")
        }
        func updateTimeLeftLabel() {
            let formatter = DateComponentsFormatter()
            formatter.allowedUnits = [.day, .hour, .minute, .second]
            formatter.unitsStyle = .full
            formatter.zeroFormattingBehavior = .dropAll
            let timeLeftString = formatter.string(from: Date(), to: date)!
            countDown.text = "\(timeLeftString) Left"
        }
        updateTimeLeftLabel()
        let timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { timer in
            updateTimeLeftLabel()
        }
        getNotification.scheduleNotification(title: "Alert!", body: "New Match Started after 10 Mins", matchStartTime: date)
    }
}
