//
//  NoLiveAvailableCollectionViewCell.swift
//  cricArena
//
//  Created by bjit on 15/2/23.
//

import UIKit

class NoLiveAvailableCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
