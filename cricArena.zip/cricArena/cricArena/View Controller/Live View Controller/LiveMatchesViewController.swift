//
//  LiveMatchesViewController.swift
//  cricArena
//
//  Created by bjit on 20/2/23.
//

import UIKit
class LiveMatchesViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
